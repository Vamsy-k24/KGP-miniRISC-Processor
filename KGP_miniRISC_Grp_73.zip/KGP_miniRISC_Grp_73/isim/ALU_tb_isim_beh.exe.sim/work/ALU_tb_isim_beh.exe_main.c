/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000004206985534_0754440821_init();
    work_m_00000000002665541859_3147002688_init();
    work_m_00000000002228480948_2962127627_init();
    work_m_00000000000025657829_2528794150_init();
    work_m_00000000002020066507_3720602196_init();
    work_m_00000000002866439458_0886308060_init();
    work_m_00000000002912622544_4236420359_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000002912622544_4236420359");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
